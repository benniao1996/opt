package main //1

import "fmt" //2

func main() {//3
   fmt.Println("Hello")//4
}